/**
 * FXML Controller class
 *
 * @author Trevor
 */
package coinsleuth;

import javafx.fxml.FXML;
import java.util.ResourceBundle;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.TextFlow;
import javafx.util.Callback;

public class CoinInterfaceController implements Initializable {

    @FXML
    private Button favButton;
    @FXML
    private Button unfavButton;
    @FXML
    private TextField tickerInputFav;
    @FXML
    private TextField tickerInputStat;
    @FXML
    private Button searchStatButton;
    @FXML
    private Button searchFavButton;
    @FXML
    private TableView<?> favTable;
    @FXML
    private Button investButton;
    @FXML
    private TextField tickerInputInvest;
    @FXML
    private Button searchInvestButton;
    @FXML
    private TableView<String> topTable;
    @FXML
    private TextField tickerInputInfo;
    @FXML
    private Button searchInfoButton;
    @FXML
    private TableView<?> invTable;
    @FXML
    private TextFlow coinInfoText;
    @FXML
    private TableView<String> statTable;
    @FXML
    private TableView<Coin> coinTable;
    @FXML
    private TabPane tabPane;
    
    @FXML
    private Tab topTab;
    @FXML
    private Tab favTab;
    @FXML
    private Tab invTab;
    @FXML
    private Tab coinTab;
    
    @FXML
    private TableColumn<String, String> topTableC1;
    @FXML
    private TableColumn<String, String> topTableC2;
    @FXML
    private TableColumn<?, ?> topTableC3;
    @FXML
    private TableColumn<?, ?> topTableC4;
    @FXML
    private TableColumn<?, ?> topTableC5;
    @FXML
    private TableColumn<?, ?> topTableC6;
    
    private static CoinList clObj;
    private ObservableList<String> temp;
    
    @FXML
    private void favButtonhandle(ActionEvent event) {
        System.out.println("Favorite Button");
    }
    
    @FXML
    private void unfavButtonhandle(ActionEvent event) {
        System.out.println("Unfavorite Button");
    }
    
    @FXML
    private void searchStatButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputStat.getText().isEmpty()){
            System.out.println("Its empty");
            tabPane.getSelectionModel().select(coinTab);
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchFavButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputFav.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchInvestButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputInvest.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchInfoButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputInfo.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void investButtonhandle(ActionEvent event) {
        System.out.println("Invest Button");
    }
    
    //using this method to try and figure out how Table View and Table Columns work
    //for displaying information... Currently not working
    private void updateTops(){
        temp = FXCollections.observableArrayList();
        for(Coin coin: clObj.coinList){
            temp.add(coin.getTICKER());
        }
        System.out.println(temp);
        topTable.setItems(temp);
        System.out.println("Hello");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clObj = new CoinList();
        updateTops();
    }  
    
}
