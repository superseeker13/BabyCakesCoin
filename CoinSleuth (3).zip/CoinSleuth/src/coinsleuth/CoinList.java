package coinsleuth;

import java.util.Iterator;
import org.json.JSONObject;

import java.util.LinkedList;
import java.util.List;
import java.util.Observable;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Edward Conn
 */
public class CoinList extends Observable {

    private static final CoinFetcherClient CFC = new CoinFetcherClient();
    public ObservableList<Coin> coinList; //Hack fix.
    
    //Constructor for list of coins
    public CoinList() {
        //calls the update function
        coinList = updateCoinList();
        //Updates the List every 60 seconds.
        ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(() -> {
            coinList = updateCoinList();
            setChanged();
            notifyObservers();
        }, -1L, 60L, TimeUnit.SECONDS);

    }
    
    //function to get data from API and reload the list
    private ObservableList<Coin> updateCoinList() {
        ObservableList<Coin> result = FXCollections.observableArrayList();
        String str = CFC.getAllCoinsJSON();
        //System.out.println(str);
        JSONObject raw = new JSONObject(str).getJSONObject("RAW");

        Iterator<String> keyIter = raw.keys();
        while (keyIter.hasNext()) {
            String key = keyIter.next();
            JSONObject currentCoin = raw.getJSONObject(key);
            JSONObject currentUSDCOIN = currentCoin.getJSONObject("USD");
            System.out.println(key);
            System.out.println(currentCoin.toString());
            result.add(new Coin(key, currentUSDCOIN));
        }
        //returns list of Coin objects
        return result;
    }
}
