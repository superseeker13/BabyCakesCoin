/**
 * FXML Controller class
 *
 * @author Trevor
 */
package coinsleuth;

import javafx.fxml.FXML;
import java.util.ResourceBundle;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.TextFlow;
import javafx.util.Callback;

public class CoinInterfaceController implements Initializable {

    @FXML
    private Button favButton;
    @FXML
    private Button unfavButton;
    @FXML
    private Button searchStatButton;
    @FXML
    private Button searchFavButton;
    @FXML
    private Button investButton;
    @FXML
    private Button searchInvestButton;
    @FXML
    private Button searchInfoButton;
    @FXML
    private Button sellBtn;
    
    @FXML
    private TextField tickerInputFav;
    @FXML
    private TextField tickerInputStat;
    @FXML
    private TextField tickerInputInvest;
    
    @FXML
    private TextFlow coinInfoText;
       
    @FXML
    private TextField tickerInputInfo;
    
    @FXML
    private TabPane tabPane;
    
    @FXML
    private TableView<Coin> favTable;
    @FXML
    private TableView<Coin> coinTable;
    @FXML
    private TableView<Coin> statTable;
    @FXML
    private TableView<Investment> invTable;
    @FXML
    private TableView<Coin> topTable;
    
    @FXML
    private Tab topTab;
    @FXML
    private Tab favTab;
    @FXML
    private Tab invTab;
    @FXML
    private Tab coinTab;
    
    @FXML
    private TableColumn<Coin, String> topTableC1;
    @FXML
    private TableColumn<Coin, String> topTableC2;
    @FXML
    private TableColumn<Coin, String> topTableC3;
    @FXML
    private TableColumn<Coin, Double> topTableC4;
    @FXML
    private TableColumn<Coin, Double> topTableC5;
    @FXML
    private TableColumn<Coin, Double> topTableC6;
    @FXML
    private TableColumn<Coin, String> favTableC1;
    @FXML
    private TableColumn<Coin, String> favTableC2;
    @FXML
    private TableColumn<Coin, String> favTableC3;
    @FXML
    private TableColumn<Coin, Double> favTableC4;
    @FXML
    private TableColumn<Coin, Double> favTableC5;
    @FXML
    private TableColumn<Coin, Double> favTableC6;
    @FXML
    private TableColumn<Coin, String> invTableC1;
    @FXML
    private TableColumn<Coin, String> invTableC2;
    @FXML
    private TableColumn<Coin, Double> invTableC3;
    @FXML
    private TableColumn<Coin, Double> invTableC4;
    @FXML
    private TableColumn<Coin, Double> invTableC5;
    @FXML
    private TableColumn<Coin, Double> invTableC6;
    @FXML
    private TableColumn<Coin, Double> invTableC7;
    @FXML
    private TableColumn<Coin, String> coinTableC1;
    @FXML
    private TableColumn<Coin, String> coinTableC2;
    
    private static ObservableList<Coin> coinList = FXCollections.observableArrayList();
    private static CoinList clObj;
    private static List<String> favTickers = new ArrayList<>();
    private static ObservableList<Coin> favList = FXCollections.observableArrayList();
    private static List<String> invTickers = new  ArrayList<>();
    private static ObservableList<Investment> invList = FXCollections.observableArrayList();
    

    @FXML
    private void favButtonhandle(ActionEvent event) {
        Coin coin = topTable.getSelectionModel().getSelectedItem();
        if(!favTickers.contains(coin.getTICKER())){
            System.out.println(coin);
            favTickers.add(coin.getTICKER());
            favList.addAll(coin);
            updateTables();
        }
    }
    
    @FXML
    private void unfavButtonhandle(ActionEvent event) {
        Coin coin = favTable.getSelectionModel().getSelectedItem();
        if(favTickers.contains(coin.getTICKER())){
            favList.remove(coin);
            favTickers.remove(coin.getTICKER());
            updateTables();
        }
    }
    
    @FXML
    private void searchStatButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputStat.getText().isEmpty()){
            System.out.println("Its empty");
            tabPane.getSelectionModel().select(coinTab);
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchFavButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputFav.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchInvestButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputInvest.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchInfoButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(tickerInputInfo.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void investButtonhandle(ActionEvent event) {
        Coin coin = topTable.getSelectionModel().getSelectedItem();
        if(!invTickers.contains(coin.getTICKER())){
            System.out.println(coin);
            invTickers.add(coin.getTICKER());
            invList.addAll(new Investment(coin, 1.0));
            updateTables();
        }
        System.out.println(invList);
    }
    
    @FXML
    void onSell(ActionEvent event) {
        Investment investment = invTable.getSelectionModel().getSelectedItem();
        if(invTickers.contains(investment.getTicker())){
            invList.remove(investment);
            invTickers.remove(investment.getTicker());
            updateTables();
        }
        System.out.println(invList);
    }
    
    //Updates all tables
    @FXML
    private void updateTables(){
 
        System.out.println("Tables updating...\n\n");
        topTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
        topTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
        topTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
        topTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
        topTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
        topTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
        topTable.setItems(clObj.coinList);
        coinTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
        coinTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
        coinTable.setItems(clObj.coinList);
 
        if(!favList.isEmpty()){
            favTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
            favTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
            favTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
            favTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
            favTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
            favTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
            favTable.setItems(favList);
        }
        
//        for(Investment inv: invList){
//            System.out.println(inv.getTicker());
//        }
        
        System.out.println();
        ObservableList<Investment> tempInvests = FXCollections.observableArrayList();
        invList.stream().forEach(inv -> clObj.coinList.stream()
                .filter(coin -> coin.getTICKER().equals(inv.getTicker()))
                .forEach(coin -> tempInvests.add(new Investment(coin, inv.getQuantity(), inv.getBought()))));
        
        invList = tempInvests;
        
//        for(Investment inv: tempInvests){
//            System.out.println(inv.getTicker());
//        }
        
        if(!invList.isEmpty()){
            invTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
            invTableC2.setCellValueFactory(new PropertyValueFactory<>("Ticker"));
            invTableC3.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
            invTableC4.setCellValueFactory(new PropertyValueFactory<>("Bought"));
            invTableC5.setCellValueFactory(new PropertyValueFactory<>("Price"));
            invTableC6.setCellValueFactory(new PropertyValueFactory<>("Net"));
            invTableC7.setCellValueFactory(new PropertyValueFactory<>("Change"));
            invTable.setItems(invList);
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clObj = new CoinList();
        updateTables();
    }
}
