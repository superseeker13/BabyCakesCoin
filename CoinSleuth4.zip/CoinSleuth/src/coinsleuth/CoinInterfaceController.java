/**
 * FXML Controller class
 *
 * @author Trevor
 */
package coinsleuth;

import javafx.fxml.FXML;
import java.util.ResourceBundle;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.TextFlow;
import javafx.util.Callback;

public class CoinInterfaceController implements Initializable {

    @FXML
    private Button favButton;
    @FXML
    private Button unfavButton;
    @FXML
    private Button topSearchBar;
    @FXML
    private Button favSearchBtn;
    @FXML
    private Button investButton;
    @FXML
    private Button invSearchBtn;
    @FXML
    private Button coinSearchBtn;
    @FXML
    private Button sellBtn;
    
    @FXML
    private TextField favSearchTxt;
    @FXML
    private TextField topSearchTxt;
    @FXML
    private TextField invSearchTxt;
    @FXML
    private TextField coinSearchTxt;
    
    @FXML
    private TextArea coinInfoText;
    @FXML
    private TextArea desc1;
    @FXML
    private TextArea desc2;
    @FXML
    private TextArea desc3;
       
    @FXML
    private TextField tickerInputInfo;
    
    @FXML
    private TabPane tabPane;
    
    @FXML
    private TableView<Coin> favTable;
    @FXML
    private TableView<Coin> coinTable;
    @FXML
    private TableView<Coin> statTable;
    @FXML
    private TableView<Investment> invTable;
    @FXML
    private TableView<Coin> topTable;
    
    @FXML
    private Tab topTab;
    @FXML
    private Tab favTab;
    @FXML
    private Tab invTab;
    @FXML
    private Tab coinTab;
    
    @FXML
    private TableColumn<Coin, String> topTableC1;
    @FXML
    private TableColumn<Coin, String> topTableC2;
    @FXML
    private TableColumn<Coin, String> topTableC3;
    @FXML
    private TableColumn<Coin, Double> topTableC4;
    @FXML
    private TableColumn<Coin, Double> topTableC5;
    @FXML
    private TableColumn<Coin, Double> topTableC6;
    @FXML
    private TableColumn<Coin, String> favTableC1;
    @FXML
    private TableColumn<Coin, String> favTableC2;
    @FXML
    private TableColumn<Coin, String> favTableC3;
    @FXML
    private TableColumn<Coin, Double> favTableC4;
    @FXML
    private TableColumn<Coin, Double> favTableC5;
    @FXML
    private TableColumn<Coin, Double> favTableC6;
    @FXML
    private TableColumn<Coin, String> invTableC1;
    @FXML
    private TableColumn<Coin, String> invTableC2;
    @FXML
    private TableColumn<Coin, Double> invTableC3;
    @FXML
    private TableColumn<Coin, Double> invTableC4;
    @FXML
    private TableColumn<Coin, Double> invTableC5;
    @FXML
    private TableColumn<Coin, Double> invTableC6;
    @FXML
    private TableColumn<Coin, Double> invTableC7;
    @FXML
    private TableColumn<Coin, String> coinTableC1;
    @FXML
    private TableColumn<Coin, String> coinTableC2;
    
    @FXML
    private Hyperlink link1;
    @FXML
    private Hyperlink link3;
    @FXML
    private Hyperlink link2;
    
    private static ObservableList<Coin> coinList = FXCollections.observableArrayList();
    private static CoinList clObj;
    private static List<String> favTickers = new ArrayList<>();
    private static ObservableList<Coin> favList = FXCollections.observableArrayList();
    private static List<String> invTickers = new  ArrayList<>();
    private static ObservableList<Investment> invList = FXCollections.observableArrayList();
    private static ArticleList articles;
    

    @FXML
    private void favButtonhandle(ActionEvent event) {
        try{
            Coin coin = topTable.getSelectionModel().getSelectedItem();
            if(!favTickers.contains(coin.getTICKER())){
                System.out.println(coin);
                favTickers.add(coin.getTICKER());
                favList.addAll(coin);
                updateTables();
            }
        }catch(NullPointerException e){
            System.out.println("No selection");
        }
    }
    
    @FXML
    private void unfavButtonhandle(ActionEvent event) {
        try{
            Coin coin = favTable.getSelectionModel().getSelectedItem();
            if(favTickers.contains(coin.getTICKER())){
                favList.remove(coin);
                favTickers.remove(coin.getTICKER());
                updateTables();
            }
        }catch(NullPointerException e){
            System.out.println("No selection");
        }
    }
    
    @FXML
    private void searchStatButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(topSearchTxt.getText().isEmpty()){
            System.out.println("Its empty");
            updateTables();
        }
        else{
            if(!coinList.isEmpty()){
                ObservableList<Coin> searchList = FXCollections.observableArrayList();
                for(Coin coin:coinList){
                    if(coin.getTICKER().toLowerCase().equals(topSearchTxt.getText().toLowerCase())||
                            coin.getName().toLowerCase().equals(topSearchTxt.getText().toLowerCase())){
                        searchList.add(coin);
                        break;
                    }
                }
                topTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
                topTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
                topTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
                topTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
                topTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
                topTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
                topTable.setItems(searchList);
                topSearchTxt.clear();
            }
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchFavButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(favSearchTxt.getText().isEmpty()){
            System.out.println("Its empty");
            updateTables();
        }
        else{
            if(!favList.isEmpty()){
                ObservableList<Coin> searchList = FXCollections.observableArrayList();
                for(Coin coin:favList){
                    if(coin.getTICKER().toLowerCase().equals(favSearchTxt.getText().toLowerCase())||
                            coin.getName().toLowerCase().equals(favSearchTxt.getText().toLowerCase())){
                        searchList.add(coin);
                        break;
                    }
                }
                favTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
                favTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
                favTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
                favTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
                favTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
                favTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
                favTable.setItems(searchList);
                favSearchTxt.clear();
            }
            System.out.println("Its Populated");
        }
    }
    
    @FXML
    private void searchInvestButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(invSearchTxt.getText().isEmpty()){
            System.out.println("Its empty");
            updateTables();
        }
        else{
            System.out.println("Its Populated");
            if(!invList.isEmpty()){
                ObservableList<Investment> searchList = FXCollections.observableArrayList();
                for(Investment inv:invList){
                    if(inv.getTicker().toLowerCase().equals(invSearchTxt.getText().toLowerCase())||
                            inv.getName().toLowerCase().equals(invSearchTxt.getText().toLowerCase())){
                        searchList.add(inv);
                        break;
                    }
                }
                invTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
                invTableC2.setCellValueFactory(new PropertyValueFactory<>("Ticker"));
                invTableC3.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
                invTableC4.setCellValueFactory(new PropertyValueFactory<>("Bought"));
                invTableC5.setCellValueFactory(new PropertyValueFactory<>("Price"));
                invTableC6.setCellValueFactory(new PropertyValueFactory<>("Net"));
                invTableC7.setCellValueFactory(new PropertyValueFactory<>("Change"));
                invTable.setItems(searchList);
                invSearchTxt.clear();
            }
        }
    }
    
    @FXML
    private void searchInfoButtonhandle(ActionEvent event) {
        System.out.println("Search");
        // Search 
        if(coinSearchTxt.getText().isEmpty()){
            System.out.println("Its empty");
        }
        else{
            System.out.println("Its Populated");
                Coin Coin;
                for(Coin coin:coinList){
                    if(coin.getTICKER().toLowerCase().equals(coinSearchTxt.getText().toLowerCase()) ||
                        coin.getName().toLowerCase().equals(coinSearchTxt.getText().toLowerCase())){
                        coinInfoText.setText(coin.toString());
                        String name = coin.getName();
                        link1.setText(name + " News Article 1 Headline");
                        link2.setText(name + " News Article 2 Headline");
                        link3.setText(name + " News Article 3 Headline");
                        desc1.setText("Description of the relevant " + name + "article.");                 
                        desc2.setText("Description of the relevant " + name + "article.");
                        desc3.setText("Description of the relevant " + name + "article.");
                        break;
                    }
                }
                coinSearchTxt.clear();
        }
    }
    
    
    @FXML
    private void investButtonhandle(ActionEvent event) {
        Coin coin = topTable.getSelectionModel().getSelectedItem();
        if(!invTickers.contains(coin.getTICKER())){
            System.out.println(coin);
            invTickers.add(coin.getTICKER());
            invList.addAll(new Investment(coin, 1.0));
            updateTables();
        }
        System.out.println(invList);
    }
    
    @FXML
    void onSell(ActionEvent event) {
        try{
            Investment investment = invTable.getSelectionModel().getSelectedItem();
            if(invTickers.contains(investment.getTicker())){
                invList.remove(investment);
                invTickers.remove(investment.getTicker());
                updateTables();
            }
            System.out.println(invList);
        }catch(NullPointerException e){
            System.out.println("No selection");
        }
    }
    
    //Updates all tables
    @FXML
    private void updateTables(){
        System.out.println("Tables updating...\n\n");
        topTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
        topTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
        topTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
        topTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
        topTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
        topTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
        topTable.setItems(coinList);
        coinTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
        coinTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
        coinTable.setItems(coinList);
 
        if(!favList.isEmpty()){
            favTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
            favTableC2.setCellValueFactory(new PropertyValueFactory<>("TICKER"));
            favTableC3.setCellValueFactory(new PropertyValueFactory<>("Volume"));
            favTableC4.setCellValueFactory(new PropertyValueFactory<>("Price"));
            favTableC5.setCellValueFactory(new PropertyValueFactory<>("Supply"));
            favTableC6.setCellValueFactory(new PropertyValueFactory<>("Change"));
            favTable.setItems(favList);
        }
        
//        for(Investment inv: invList){
//            System.out.println(inv.getTicker());
//        }
        
        System.out.println();
        ObservableList<Investment> tempInvests = FXCollections.observableArrayList();
        invList.stream().forEach(inv -> coinList.stream()
                .filter(coin -> coin.getTICKER().equals(inv.getTicker()))
                .forEach(coin -> tempInvests.add(new Investment(coin, inv.getQuantity(), inv.getBought()))));
        
        invList = tempInvests;
        
//        for(Investment inv: tempInvests){
//            System.out.println(inv.getTicker());
//        }
        
        if(!invList.isEmpty()){
            invTableC1.setCellValueFactory(new PropertyValueFactory<>("Name"));
            invTableC2.setCellValueFactory(new PropertyValueFactory<>("Ticker"));
            invTableC3.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
            invTableC4.setCellValueFactory(new PropertyValueFactory<>("Bought"));
            invTableC5.setCellValueFactory(new PropertyValueFactory<>("Price"));
            invTableC6.setCellValueFactory(new PropertyValueFactory<>("Net"));
            invTableC7.setCellValueFactory(new PropertyValueFactory<>("Change"));
            invTable.setItems(invList);
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clObj = new CoinList();
        coinList = clObj.updateList();
        System.out.println(coinList);
        updateTables();
    }
}
