package coinsleuth;

import java.util.Iterator;
import org.json.JSONObject;
import java.util.LinkedList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Edward Conn
 */
public class CoinList extends UpdatedList<Coin> {
    private static final CoinFetcherClient CFC = new CoinFetcherClient();

    @Override
    public ObservableList<Coin> updateList() {
        System.out.println("update list");
        String str = CFC.getAllCoinsJSON();
        JSONObject raw = new JSONObject(str).getJSONObject("RAW");
        return parseJSON(raw);
    }

    private ObservableList<Coin> parseJSON(JSONObject jsObj) {
        ObservableList<Coin> result = FXCollections.observableArrayList();
        Iterator<String> keyIter = jsObj.keys();
        List<String> names = CFC.getNameList();
        List<String> tickers = CFC.getTickerList();
        int index;
        while (keyIter.hasNext()) {
            String key = keyIter.next();
            JSONObject currentCoin = jsObj.getJSONObject(key);
            JSONObject currentUSDCOIN = currentCoin.getJSONObject("USD");
            System.out.println(key);
            //System.out.println(currentCoin.toString());
            index = tickers.indexOf(key);
            Coin newCoin = new Coin(names.get(index), key, currentUSDCOIN);
            result.add(newCoin);
        }
        return result;
    }
}
