package coinsleuth;

import org.json.JSONObject;

/**
 *
 * @author Edward Conn
 */
public class Coin {

    private final String NAME;
    private final String TICKER;
    private final Double VOLUMEDAY;
    private final Double PRICE;
    private final Double SUPPLY;
    private final Double CHANGE;

    public Coin(String Name, String Ticker, Double volume, Double price, Double supply, Double change) {
        this.NAME = Name;
        this.TICKER = Ticker;
        this.VOLUMEDAY = volume;
        this.PRICE = price;
        this.SUPPLY = supply;
        this.CHANGE = change;
    }

    public Coin(final String NAME, final String TICKER, final JSONObject jsonObj) {
        this.NAME = NAME;
        this.TICKER = TICKER;
        this.VOLUMEDAY = jsonObj.getDouble("VOLUMEDAY");
        this.PRICE = jsonObj.getDouble("PRICE");
        this.SUPPLY = jsonObj.getDouble("SUPPLY");
        this.CHANGE =  jsonObj.getDouble("CHANGEPCTDAY");
    }

    public JSONObject toJSON() {
        return new JSONObject(String.format("{TICKER:%s,VOLUMEDAY:%.4f,PRICE:%.4f,SUPPLY%.4f,CHANGEPCTDAY:%.4f}",
                TICKER, VOLUMEDAY, PRICE, SUPPLY, CHANGE));
    }
    
    public String getName(){
        return NAME;
    }
    
    public String getTICKER() {
        return TICKER;
    }

    public Double getVolume() {
        return VOLUMEDAY;
    }

    public Double getPrice() {
        return PRICE;
    }

    public Double getSupply() {
        return SUPPLY;
    }
    
    public Double getChange(){
        return CHANGE;
    }
    
    public String toString(){
        return "Name: " + NAME + "\nTicker: " + TICKER 
                + "\n\nPrice: $" + PRICE + "\n24 Hour Change: " + CHANGE + "%" 
                + "\n\nVolume: " + VOLUMEDAY + "\nSupply: " + SUPPLY;
    }
}
