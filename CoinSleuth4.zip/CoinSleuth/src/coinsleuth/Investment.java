/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coinsleuth;

import java.util.Date;

/**
 *
 * @author aquat
 */
public class Investment {
    private Coin coin;
    private Date date;
    private Double bought;
    private Double quantity;
    private Double investment;
    private Double change;
    public Investment(Coin coin, Double amt){
        this.coin = coin;
        this.bought = coin.getPrice();
        this.quantity = amt;
        this.investment = bought * amt;
        this.change = 0.0;
    }
    
    public Investment(Coin coin, Double amt, Double b){
        this.coin = coin;
        this.bought = b;
        this.quantity = amt;
        this.investment = bought * amt;
        this.change = updateChange();
    }
    
    public Double updateChange(){
        return change = (coin.getPrice() - bought)/bought * 100;
    }
    
    public String getName(){
        return coin.getName();
    }
    
    public String getTicker(){
        return coin.getTICKER();
    }
    
    public Double getQuantity(){
        return quantity;
    }
    
    public Double getBought(){
        return bought;
    }
    
    public Double getChange(){
        updateChange();
        return change;
    }
    
    public Double getNet(){
        return investment*(change/100);
    }
    
    public Double getPrice(){
        return coin.getPrice();
    }
}
